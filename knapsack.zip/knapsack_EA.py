import random
import os
import time
import statistics
import matplotlib.pyplot as plt
from contextlib import contextmanager
from EA import Knapsack

@contextmanager
def timer(label: str, timelst):
    start = time.perf_counter()
    try:
        yield
    finally:
        end = time.perf_counter()
        timelst.append(end - start)

def main(plotting_instances=[]):
    categories = ["very_large_n"]
    instances = 100
    iterations = 3
    avg_score = []; avg_time = []
    n_lst = []; c_lst = []
    w_lst = []; v_lst = []

    for c in categories:
        for i in range(instances):
            score = []; timelst = []
            location = f"../Dataset/{c}_group/instance_{str(i).zfill(4)}.txt"
            items, num, capacity = load_data(location)
            
            for _ in range(iterations):
                with timer("func", timelst):
                    max_value = Knapsack(location).solve()
                score.append(max_value)

            avg_score.append(statistics.mean(score))
            avg_time.append(statistics.mean(timelst))
            w_lst.append(statistics.mean([item[1] for item in items]))
            v_lst.append(statistics.mean([item[0] for item in items]))
            n_lst.append(num)
            c_lst.append(capacity)

    return list(zip(n_lst, avg_time, c_lst))

def load_data(file_path):
    with open(file_path) as file:
        lines = file.readlines()
        num, capacity = map(int, lines[0].split())
        items = [tuple(map(int, line.split())) for line in lines[1:]]
    return items, num, capacity

if "__name__" == "__main__":
    main()

def eaplot(plotting_instances = []):
    plotting_instances.append(main(plotting_instances))
    for data in plotting_instances:
        plt.plot(data[0], data[1], color='blue', label="")
    plt.xlabel('n')
    plt.ylabel('Time (seconds)')
    plt.legend()
    plt.title('Knapsack - EA')
    plt.show()

def wmax(plotting_instances):
    categories = ["very_large_wmax"]
    instances = 100
    iterations = 1
    avg_score = []; avg_time = []
    n_lst = []; c_lst = []

    for c in categories:
        for i in range(instances):
            score = []; timelst = []
            location = f"../Dataset/{c}_group/instance_{str(i).zfill(4)}.txt"
            items, num, capacity = load_data(location)

            for _ in range(iterations):
                with timer("func", timelst):
                    max_value = Knapsack(location).solve()
                score.append(max_value)

            avg_score.append(statistics.mean(score))
            avg_time.append(statistics.mean(timelst))
            n_lst.append(num)
            c_lst.append(capacity)

    plotting_instances.append(list(zip(c_lst, avg_time)))
    return plotting_instances
