import os
import time
import statistics
from contextlib import contextmanager
import matplotlib.pyplot as plt

def knapsack(items, capacity):
    # Sort items by value-to-weight ratio in descending order
    items.sort(key=lambda x: x[0] / x[1], reverse=True)
    total_value = 0
    selected_items = []
    for value, weight in items:
        if capacity >= weight:
            total_value += value
            selected_items.append((value, weight))
            capacity -= weight
    return total_value

@contextmanager
def timer(label, timelst):
    start = time.perf_counter()
    yield
    end = time.perf_counter()
    timelst.append(end - start)

def wmax(plotting_instances):
    categories = ["very_large_wmax"]
    instances = 100
    iterations = 1
    avg_score = list(); avg_time = list()
    n_lst = list(); c_lst = list()
    for c in categories:
        for i in range(instances):
            score = list()
            timelst = list()
            num = "0"*(4-len(str(i)))
            location = f"../Dataset/{c}_group/instance_{num}{i}.txt"
            items = list(); W = list(); V = list()
            with open(location) as f:
                lines = f.readlines()
                num, capacity = lines[0].split()
                num, capacity = int(num), int(capacity)
                for i in lines[1::]:
                    value, weight = i.split()
                    items.append((int(value), int(weight)))
                    W.append(int(weight)); V.append(int(value))
                    
            for i in range(iterations):
                with timer("func", timelst):
                    max = knapsack(items, capacity)
                score.append(max)
            n_lst.append(num)
            c_lst.append(capacity)
            avg_score.append(statistics.mean(score))
            avg_time.append(statistics.mean(timelst))
            c_t = list(zip(c_lst, avg_time))
            c_t.sort(key=lambda x: x[0])
            c_list, time_list = zip(*c_t)
    with open('analysis2.csv', 'w') as f:
        f.write("score, time\n")
        for i in range(instances*len(categories)):
            if i % instances == 0:
                f.write(f"{categories[i//instances]}\n")
            f.write(f"{avg_score[i]}, {avg_time[i]}\n")
    
    plotting_instances.append((c_list, time_list))
    return plotting_instances


def main(plotting_instances=[]):
    categories = ["very_large_n"]
    instances = 100
    iterations = 3
    avg_score, avg_time = [], []
    for c in categories:
        for i in range(instances):
            score, timelst = [], []
            with open(f"../Dataset/{c}_group/instance_{str(i).zfill(4)}.txt") as f:
                lines = f.readlines()
                num, capacity = map(int, lines[0].split())
                items = [(int(v), int(w)) for v, w in (line.split() for line in lines[1:])]

            for _ in range(iterations):
                with timer("func", timelst):
                    max_value = knapsack(items, capacity)
                score.append(max_value)

            avg_score.append(statistics.mean(score))
            avg_time.append(statistics.mean(timelst))
    
    # Data for plotting
    n_list, time_list, c_list = range(instances), avg_time, capacity
    plotting_instances.append((n_list, time_list))
    return plotting_instances

def greedyplot(plotting_instances=[]):
    data = main(plotting_instances)
    for n_list, time_list in data:
        plt.plot(n_list, time_list)
    plt.xlabel('Instance')
    plt.ylabel('Time (seconds)')
    plt.title('Performance Analysis')
    plt.show()

    return data

if __name__ == "__main__":
    plotting_instances = []
    greedyplot(plotting_instances)
